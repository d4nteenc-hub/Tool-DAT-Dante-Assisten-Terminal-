"""DAT - Dante Assistant Terminal."""

__version__ = "1.0.0"
